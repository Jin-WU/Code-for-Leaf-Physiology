This folder contains files output from 'import_and_format_clean_licor_files.m' for input into __________
