This folder contains files output from 'import_and_format_clean_licor_files.m' for input 
into Test_Environmental_Variable_Extraction_V1.m

Right now these files need to be copied over, but could write a script to move them over 
(or change directory of output).